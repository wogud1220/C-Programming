

typedef struct data {
    char name[20];
    char number[20];
    struct data* next;
}data;